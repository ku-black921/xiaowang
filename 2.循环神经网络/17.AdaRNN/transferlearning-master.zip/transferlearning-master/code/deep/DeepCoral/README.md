# Deep Coral

This implementation has been moved to [DDC_DeepCoral](https://github.com/jindongwang/transferlearning/tree/master/code/deep/DDC_DeepCoral) for better union with the mmd loss.