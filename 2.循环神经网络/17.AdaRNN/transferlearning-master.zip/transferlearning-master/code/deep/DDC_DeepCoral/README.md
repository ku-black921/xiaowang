# Deep Coral and DDC


Code has been rewritten. Please go to https://github.com/jindongwang/transferlearning/tree/master/code/DeepDA for the unified code implementation.