""" This module is adapted from Jindong Wang <jindong.wang@microsoft.com>
    <https://github.com/jindongwang>.
"""
