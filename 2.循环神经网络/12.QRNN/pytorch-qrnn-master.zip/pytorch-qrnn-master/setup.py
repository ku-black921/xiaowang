from distutils.core import setup

setup(
    name='PyTorch-QRNN',
    version='0.2.1',
    packages=['torchqrnn',],
    license='BSD 3-Clause License'
)
