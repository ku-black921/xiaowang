# Examples

This folder contains actively maintained examples of use of Flair, organized along various NLP tasks.

## Table of Tasks

| Task                          | Documentation
| ----------------------------- | -------------
| Named Entity Recognition (NER) | [Here](ner/)
